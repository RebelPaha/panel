-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 16 2013 г., 10:37
-- Версия сервера: 5.5.27-log
-- Версия PHP: 5.3.16

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `panel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `AuthAssignment`
--

CREATE TABLE IF NOT EXISTS `AuthAssignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthAssignment`
--

INSERT INTO `AuthAssignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('admin', '1', NULL, 'N;'),
('admin', '4', NULL, 'N;'),
('manager', '20', NULL, 'N;'),
('user', '17', '', 'N;'),
('user', '18', NULL, 'N;'),
('user', '19', NULL, 'N;'),
('user.create.admin', '1', NULL, 'N;');

-- --------------------------------------------------------

--
-- Структура таблицы `AuthItem`
--

CREATE TABLE IF NOT EXISTS `AuthItem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthItem`
--

INSERT INTO `AuthItem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('admin', 2, 'admin', NULL, 'N;'),
('invite.*', 1, 'Manage Invites', NULL, 'N;'),
('manager', 2, 'Manager', NULL, 'N;'),
('ticket.*', 1, 'Tickets Full Access', NULL, 'N;'),
('ticket.create', 0, 'Create Ticket', NULL, 'N;'),
('ticket.delete', 0, 'Delete Ticket', NULL, 'N;'),
('ticket.manage', 0, 'Manage Tickets', NULL, 'N;'),
('ticket.to.admin', 1, 'Ticket To Admin', NULL, 'N;'),
('ticket.toggle', 0, 'Open/Close Ticket', NULL, 'N;'),
('ticket.view', 0, 'View Ticket', NULL, 'N;'),
('user', 2, 'User', NULL, 'N;'),
('user.create', 0, 'Create User', NULL, 'N;'),
('user.create.*', 1, 'Create All Roles Users', NULL, 'N;'),
('user.create.admin', 0, 'Create Admin', NULL, 'N;'),
('user.create.manager', 0, 'Create Manager', NULL, 'N;'),
('user.create.user', 0, 'Create User(Drop)', NULL, 'N;'),
('user.manage.*', 1, 'Manage All Roles Users', NULL, 'N;'),
('user.manage.admin', 0, 'Manage Admins', NULL, 'N;'),
('user.manage.manager', 0, 'Manage Managers', NULL, 'N;'),
('user.manage.user', 0, 'Manage Users (Drops)', NULL, 'N;');

-- --------------------------------------------------------

--
-- Структура таблицы `AuthItemChild`
--

CREATE TABLE IF NOT EXISTS `AuthItemChild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthItemChild`
--

INSERT INTO `AuthItemChild` (`parent`, `child`) VALUES
('admin', 'ticket.*'),
('ticket.to.admin', 'ticket.create'),
('ticket.to.admin', 'ticket.delete'),
('ticket.to.admin', 'ticket.manage'),
('admin', 'ticket.to.admin'),
('manager', 'ticket.to.admin'),
('user', 'ticket.to.admin'),
('ticket.to.admin', 'ticket.toggle'),
('ticket.to.admin', 'ticket.view'),
('admin', 'user.create'),
('user.create.*', 'user.create.admin'),
('admin', 'user.create.manager'),
('user.create.*', 'user.create.manager'),
('admin', 'user.create.user'),
('user.create.*', 'user.create.user'),
('user.manage.*', 'user.manage.admin'),
('admin', 'user.manage.manager'),
('user.manage.*', 'user.manage.manager'),
('admin', 'user.manage.user'),
('user.manage.*', 'user.manage.user');

-- --------------------------------------------------------

--
-- Структура таблицы `Country`
--

CREATE TABLE IF NOT EXISTS `Country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=239 ;

--
-- Дамп данных таблицы `Country`
--

INSERT INTO `Country` (`id`, `name`) VALUES
(1, 'Afghanistan'),
(2, 'Albania'),
(3, 'Algeria'),
(4, 'American Samoa'),
(5, 'Andorra'),
(6, 'Angola'),
(7, 'Anguilla'),
(8, 'Antarctica'),
(9, 'Antigua And Barbuda'),
(10, 'Argentina'),
(11, 'Armenia'),
(12, 'Aruba'),
(13, 'Australia'),
(14, 'Austria'),
(15, 'Azerbaijan'),
(16, 'Bahamas, The'),
(17, 'Bahrain'),
(18, 'Bangladesh'),
(19, 'Barbados'),
(20, 'Belarus'),
(21, 'Belgium'),
(22, 'Belize'),
(23, 'Benin'),
(24, 'Bermuda'),
(25, 'Bhutan'),
(26, 'Bolivia'),
(27, 'Bosnia and Herzegovina'),
(28, 'Botswana'),
(29, 'Bouvet Island'),
(30, 'Brazil'),
(31, 'British Indian Ocean Territory'),
(32, 'Brunei'),
(33, 'Bulgaria'),
(34, 'Burkina Faso'),
(35, 'Burundi'),
(36, 'Cambodia'),
(37, 'Cameroon'),
(38, 'Canada'),
(39, 'Cape Verde'),
(40, 'Cayman Islands'),
(41, 'Central African Republic'),
(42, 'Chad'),
(43, 'Chile'),
(44, 'China'),
(45, 'China (Hong Kong S.A.R.)'),
(46, 'China (Macau S.A.R.)'),
(47, 'Christmas Island'),
(48, 'Cocos (Keeling) Islands'),
(49, 'Colombia'),
(50, 'Comoros'),
(51, 'Congo'),
(52, 'Congo, Democractic Republic of the'),
(53, 'Cook Islands'),
(54, 'Costa Rica'),
(55, 'Cote D''Ivoire (Ivory Coast)'),
(56, 'Croatia (Hrvatska)'),
(57, 'Cuba'),
(58, 'Cyprus'),
(59, 'Czech Republic'),
(60, 'Denmark'),
(61, 'Djibouti'),
(62, 'Dominica'),
(63, 'Dominican Republic'),
(64, 'East Timor'),
(65, 'Ecuador'),
(66, 'Egypt'),
(67, 'El Salvador'),
(68, 'Equatorial Guinea'),
(69, 'Eritrea'),
(70, 'Estonia'),
(71, 'Ethiopia'),
(72, 'Falkland Islands (Islas Malvinas)'),
(73, 'Faroe Islands'),
(74, 'Fiji Islands'),
(75, 'Finland'),
(76, 'France'),
(77, 'French Guiana'),
(78, 'French Polynesia'),
(79, 'French Southern Territories'),
(80, 'Gabon'),
(81, 'Gambia, The'),
(82, 'Georgia'),
(83, 'Germany'),
(84, 'Ghana'),
(85, 'Gibraltar'),
(86, 'Greece'),
(87, 'Greenland'),
(88, 'Grenada'),
(89, 'Guadeloupe'),
(90, 'Guam'),
(91, 'Guatemala'),
(92, 'Guinea'),
(93, 'Guinea-Bissau'),
(94, 'Guyana'),
(95, 'Haiti'),
(96, 'Heard and McDonald Islands'),
(97, 'Honduras'),
(98, 'Hungary'),
(99, 'Iceland'),
(100, 'India'),
(101, 'Indonesia'),
(102, 'Iran'),
(103, 'Iraq'),
(104, 'Ireland'),
(105, 'Israel'),
(106, 'Italy'),
(107, 'Jamaica'),
(108, 'Japan'),
(109, 'Jordan'),
(110, 'Kazakhstan'),
(111, 'Kenya'),
(112, 'Kiribati'),
(113, 'Korea'),
(114, 'Korea, North'),
(115, 'Kuwait'),
(116, 'Kyrgyzstan'),
(117, 'Laos'),
(118, 'Latvia'),
(119, 'Lebanon'),
(120, 'Lesotho'),
(121, 'Liberia'),
(122, 'Libya'),
(123, 'Liechtenstein'),
(124, 'Lithuania'),
(125, 'Luxembourg'),
(126, 'Macedonia, Former Yugoslav Republic of'),
(127, 'Madagascar'),
(128, 'Malawi'),
(129, 'Malaysia'),
(130, 'Maldives'),
(131, 'Mali'),
(132, 'Malta'),
(133, 'Marshall Islands'),
(134, 'Martinique'),
(135, 'Mauritania'),
(136, 'Mauritius'),
(137, 'Mayotte'),
(138, 'Mexico'),
(139, 'Micronesia'),
(140, 'Moldova'),
(141, 'Monaco'),
(142, 'Mongolia'),
(143, 'Montserrat'),
(144, 'Morocco'),
(145, 'Mozambique'),
(146, 'Myanmar'),
(147, 'Namibia'),
(148, 'Nauru'),
(149, 'Nepal'),
(150, 'Netherlands Antilles'),
(151, 'Netherlands, The'),
(152, 'New Caledonia'),
(153, 'New Zealand'),
(154, 'Nicaragua'),
(155, 'Niger'),
(156, 'Nigeria'),
(157, 'Niue'),
(158, 'Norfolk Island'),
(159, 'Northern Mariana Islands'),
(160, 'Norway'),
(161, 'Oman'),
(162, 'Pakistan'),
(163, 'Palau'),
(164, 'Panama'),
(165, 'Papua new Guinea'),
(166, 'Paraguay'),
(167, 'Peru'),
(168, 'Philippines'),
(169, 'Pitcairn Island'),
(170, 'Poland'),
(171, 'Portugal'),
(172, 'Puerto Rico'),
(173, 'Qatar'),
(174, 'Reunion'),
(175, 'Romania'),
(176, 'Russia'),
(177, 'Rwanda'),
(178, 'Saint Helena'),
(179, 'Saint Kitts And Nevis'),
(180, 'Saint Lucia'),
(181, 'Saint Pierre and Miquelon'),
(182, 'Saint Vincent And The Grenadines'),
(183, 'Samoa'),
(184, 'San Marino'),
(185, 'Sao Tome and Principe'),
(186, 'Saudi Arabia'),
(187, 'Senegal'),
(188, 'Seychelles'),
(189, 'Sierra Leone'),
(190, 'Singapore'),
(191, 'Slovakia'),
(192, 'Slovenia'),
(193, 'Solomon Islands'),
(194, 'Somalia'),
(195, 'South Africa'),
(196, 'South Georgia And The South Sandwich Islands'),
(197, 'Spain'),
(198, 'Sri Lanka'),
(199, 'Sudan'),
(200, 'Suriname'),
(201, 'Svalbard And Jan Mayen Islands'),
(202, 'Swaziland'),
(203, 'Sweden'),
(204, 'Switzerland'),
(205, 'Syria'),
(206, 'Taiwan'),
(207, 'Tajikistan'),
(208, 'Tanzania'),
(209, 'Thailand'),
(210, 'Togo'),
(211, 'Tokelau'),
(212, 'Tonga'),
(213, 'Trinidad And Tobago'),
(214, 'Tunisia'),
(215, 'Turkey'),
(216, 'Turkmenistan'),
(217, 'Turks And Caicos Islands'),
(218, 'Tuvalu'),
(219, 'Uganda'),
(220, 'Ukraine'),
(221, 'United Arab Emirates'),
(222, 'United Kingdom'),
(223, 'United States'),
(224, 'United States Minor Outlying Islands'),
(225, 'Uruguay'),
(226, 'Uzbekistan'),
(227, 'Vanuatu'),
(228, 'Vatican City State (Holy See)'),
(229, 'Venezuela'),
(230, 'Vietnam'),
(231, 'Virgin Islands (British)'),
(232, 'Virgin Islands (US)'),
(233, 'Wallis And Futuna Islands'),
(234, 'Western Sahara'),
(235, 'Yemen'),
(236, 'Yugoslavia'),
(237, 'Zambia'),
(238, 'Zimbabwe');

-- --------------------------------------------------------

--
-- Структура таблицы `Invite`
--

CREATE TABLE IF NOT EXISTS `Invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Таблица инвайтов' AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Message`
--

CREATE TABLE IF NOT EXISTS `Message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketId` int(11) NOT NULL,
  `senderId` int(11) NOT NULL,
  `text` text NOT NULL,
  `created` datetime NOT NULL,
  `isReviewed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticketId` (`ticketId`),
  KEY `fromId` (`senderId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Дамп данных таблицы `Message`
--

INSERT INTO `Message` (`id`, `ticketId`, `senderId`, `text`, `created`, `isReviewed`) VALUES
(15, 5, 1, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2013-04-09 22:10:11', 1),
(4, 5, 1, 'TEXT TEST 1', '2013-04-09 00:00:00', 1),
(14, 5, 4, '1111', '2013-04-09 11:04:50', 1),
(13, 5, 4, 'answer', '2013-04-09 10:55:17', 1),
(12, 5, 1, 'te', '2013-04-09 10:47:31', 1),
(11, 5, 1, 'ta ta ta. finish', '2013-04-09 10:41:25', 1),
(10, 5, 1, 'ta ta ta. finish', '2013-04-09 10:39:54', 1),
(17, 10, 9, 'User ticket 1 text', '2013-04-10 10:08:45', 1),
(18, 10, 9, 'Are u sleeping?', '2013-04-10 17:51:30', 1),
(19, 10, 9, 'Me Gusta', '2013-04-10 17:54:03', 1),
(20, 10, 9, 'Well done!', '2013-04-10 17:55:51', 1),
(21, 10, 9, 'U shall not pass!!!', '2013-04-10 17:57:02', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Package`
--

CREATE TABLE IF NOT EXISTS `Package` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `holder` varchar(512) NOT NULL,
  `minPrice` decimal(10,2) NOT NULL,
  `userId` int(11) NOT NULL,
  `adminId` int(11) NOT NULL,
  `status` enum('unknown','new','received','shipped','checked','sent') NOT NULL DEFAULT 'new',
  `track` text NOT NULL,
  `shop` varchar(64) NOT NULL,
  `isProblem` int(11) NOT NULL,
  `paymentMethod` tinyint(3) NOT NULL,
  `shippingDate` date NOT NULL,
  `shippingInvoice` varchar(256) NOT NULL,
  `shippingReceipt` varchar(256) NOT NULL,
  `shippingLabelCopy` int(11) NOT NULL,
  `label` int(11) NOT NULL,
  `labelTrack` int(11) NOT NULL,
  `instructions` text NOT NULL,
  `comment` text NOT NULL,
  `privateComment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `adminId` (`adminId`),
  KEY `adminId_2` (`adminId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `Package`
--

INSERT INTO `Package` (`id`, `name`, `holder`, `minPrice`, `userId`, `adminId`, `status`, `track`, `shop`, `isProblem`, `paymentMethod`, `shippingDate`, `shippingInvoice`, `shippingReceipt`, `shippingLabelCopy`, `label`, `labelTrack`, `instructions`, `comment`, `privateComment`) VALUES
(4, 'Test2', 'Top Holder', '4757.88', 17, 1, 'new', '2:11dftyn7m|2:ап76|3:пт67|3:аер6|2:екть7', '', 1, 4, '2010-07-17', '', '', 0, 0, 0, 'asedtgh', 'Lol', 'asgh');

-- --------------------------------------------------------

--
-- Структура таблицы `Profile`
--

CREATE TABLE IF NOT EXISTS `Profile` (
  `userId` int(11) NOT NULL,
  `projectId` int(11) NOT NULL,
  `firstName` varchar(24) NOT NULL,
  `middleName` varchar(24) NOT NULL,
  `lastName` varchar(24) NOT NULL,
  `countryId` int(11) NOT NULL,
  `city` varchar(64) NOT NULL,
  `address` varchar(128) NOT NULL,
  `zip` varchar(64) NOT NULL,
  `homephone` varchar(24) NOT NULL,
  `cellphone` varchar(24) NOT NULL,
  `dob` date NOT NULL,
  `lastEmployer` text NOT NULL,
  `ssn` int(11) NOT NULL,
  `comment` text NOT NULL,
  `docsAlert` tinyint(1) NOT NULL,
  `lastVisit` datetime NOT NULL,
  `regIp` varchar(15) NOT NULL COMMENT 'Registration IP',
  `userAgent` varchar(256) NOT NULL,
  `isPaid` tinyint(1) NOT NULL,
  `paidAmount` int(11) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User Profile';

--
-- Дамп данных таблицы `Profile`
--

INSERT INTO `Profile` (`userId`, `projectId`, `firstName`, `middleName`, `lastName`, `countryId`, `city`, `address`, `zip`, `homephone`, `cellphone`, `dob`, `lastEmployer`, `ssn`, `comment`, `docsAlert`, `lastVisit`, `regIp`, `userAgent`, `isPaid`, `paidAmount`) VALUES
(12, 1, 'Ien', '', 'Gillan', 1, 'New York', '17 St', '4546', '4444', '7777', '1985-02-06', '', 465, '', 1, '0000-00-00 00:00:00', '127.0.0.1', '', 1, 12),
(13, 1, '', '', '', 0, '', '', '', '', '', '0000-00-00', '', 0, '', 0, '0000-00-00 00:00:00', '127.0.0.1', '', 0, 0),
(14, 1, 'Robert', '', 'Plant', 2, 'London', '12 St', '2353', '54676', '575', '1970-03-12', 'Last Employer', 23, 'Comment', 1, '0000-00-00 00:00:00', '127.0.0.1', '', 1, 3),
(15, 1, 'test10', 'test10', 'test10', 2, 'test10', 'test10', '35', '345', '45', '1900-03-08', '456', 66, '45', 1, '0000-00-00 00:00:00', '127.0.0.1', '', 1, 3),
(16, 1, 'test1', 'test1', 'test1', 2, 'test1', 'test1', '345', '45', '5', '2010-02-04', '234test1', 333, 'test1', 1, '0000-00-00 00:00:00', '127.0.0.1', '', 1, 111),
(17, 1, 'test2', 'test2', 'test2', 2, 'test2', 'test2', '34', '345', '34', '2010-02-04', '', 567, '', 0, '2013-04-17 10:42:13', '127.0.0.1', 'Opera/9.80 (Windows NT 6.1; Edition Yx) Presto/2.12.388 Version/12.15', 0, 0),
(18, 1, '', '', '', 0, '', '', '', '', '', '0000-00-00', '', 0, '', 0, '0000-00-00 00:00:00', '127.0.0.1', '', 0, 0),
(19, 1, '', '', '', 1, '', 'TEst 11 Adress', '', '', '', '0000-00-00', '', 0, '', 0, '0000-00-00 00:00:00', '127.0.0.1', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `Project`
--

CREATE TABLE IF NOT EXISTS `Project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `url` varchar(512) NOT NULL,
  `email` varchar(64) NOT NULL,
  `isDefault` tinyint(1) NOT NULL,
  `isMain` tinyint(1) NOT NULL,
  `smtpServer` varchar(64) NOT NULL,
  `smtpDomain` varchar(64) NOT NULL,
  `smtpPort` int(6) NOT NULL,
  `smtpLogin` varchar(32) NOT NULL,
  `smtpPassword` varchar(32) NOT NULL,
  `smtpSsl` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `Project`
--

INSERT INTO `Project` (`id`, `name`, `url`, `email`, `isDefault`, `isMain`, `smtpServer`, `smtpDomain`, `smtpPort`, `smtpLogin`, `smtpPassword`, `smtpSsl`) VALUES
(1, 'Test1', 'http://test1.com', 'info@test1.com', 1, 1, '', '', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `Setting`
--

CREATE TABLE IF NOT EXISTS `Setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(128) NOT NULL,
  `value` text NOT NULL,
  `label` varchar(128) NOT NULL,
  `description` text NOT NULL,
  `group` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`key`,`group`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Дамп данных таблицы `Setting`
--

INSERT INTO `Setting` (`id`, `key`, `value`, `label`, `description`, `group`) VALUES
(1, 'MAIL_METHOD', 'sendmail', 'The method of sending messages', '', 'general'),
(2, 'INVITE_EXPIRE', '10', 'Expire date invitation', '', 'general'),
(3, 'SSN_FIELD', '1', 'SSN field in registration form', '', 'general'),
(4, 'REG_COMMENT_ENABLE', '1', 'Enable registration comment', '', 'general'),
(5, 'REG_COMMENT', 'go reg!', 'Text comment under the registration form', '', 'general'),
(6, 'SMS_ENABLE', '1', 'Enable SMS nofitication', '', 'sms'),
(7, 'SMSC_ACCOUNT', 'test sms acc', 'SMSC Account', '', 'sms'),
(8, 'SMSC_PASSWORD', 'test sms pass', 'SMSC Password', '', 'sms'),
(9, 'ITEMS_PER_PAGE', '20', 'Number of lines per page', '', 'general'),
(10, 'PACKAGE_RECEIVED', 'We are pleased to announce that the status of your parcel changed to "received". Thank you for your work.', 'Package received', 'отправляется дропу<br />дроп нажал "received"\r\n', 'templates'),
(11, 'PACKAGE_SENT', 'We are pleased to announce that the status of your parcel changed to "sent". Thank you for your work.', 'Package sent', 'отправляется дропу<br />дроп нажал "sent"', 'templates'),
(12, 'REG_APPROVED', 'Your account has been aprooved.\r\nNow you can start working.', 'Account approved', '\r\nотправляется дропу<br />админ подтвердил аккаунт', 'templates'),
(13, 'REG_DECLINED', 'Unfortunately, we have to decline your account. Sorry...', 'Account declined', 'отправляется дропу<br />админ удалил аккаунт', 'templates'),
(14, 'PROFILE_CHANGE_APPROVED', 'Hello,\r\nYour personal information has been approved and you can use it now.', 'Personal information approved', 'отправляется дропу<br />админ подтвердил изменение личной инфы', 'templates'),
(15, 'PROFILE_CHANGE_DECLINE', 'Hello,\r\nunfortunally, your personal information was declined. Sorry...', 'Personal information declined', 'отправляется дропу<br />админ не разреiил изменений личной инфы дропа', 'templates'),
(16, 'NEW_PACKAGE', 'Dear %DROPNAME%,\r\n\r\nOur customer has sent a package to you:\r\n\r\n **********************************INFORMATION********************************** \r\n\r\n ID:              #%PACKAGE_ID% \r\n Description:     %PACKAGE_NAME%\r\n Manager:         %HOLDER_NAME%\r\nPrice:           %PRICE%\r\n\r\n Delivery System: %DELIVERY_SYSTEM%\r\nTracking Number: %TRACKING_NUMBER%\r\n\r\n ***************************************************************************** \r\n\r\nYou can find more detailed information in your user panel.\r\n\r\nInstructions:\r\n1) Review all the information about the package.\r\n 2) You can track delivery time of the package in the tracking system (ups.com, fedex.com, usps.com)\r\n 3) Once you receive the package make sure you mark it as RECEIVED in the user panel.\r\n Just log in to your user panel and press the button ">I RECEIVED IT<".\r\n4) Then you will get futher instructions.\r\n\r\nNote:\r\nYou should stay at your house during the post serviceвЂ™s working hours, for at times you will have to accept parcels, addressed to our clients, i.e. with their name on the label. \r\nSince it is sometimes difficult to make a warrant, you would have to take the parcel directly from the postman, not at the office.\r\n\r\n----\r\nRegards,\r\nAutomatic notification system,\r\n%COMPANY%, LLC.', 'You got a new task', 'отправляется дропу<br />админ подвердил новый пак от стаффера', 'templates'),
(17, 'NEW_PACKAGE_SMS', 'Dear %DROPNAME%, were you added a new task. Please check your account.', 'You got a new task (SMS text)', 'отправляется дропу<br/>СМС дропу о новом паке', 'templates'),
(18, 'NEW_LABEL', 'Hello,\r\nlabel for package %PACKAGE_ID% was uploaded.\r\nInvoice #%PACKAGE_ID%.\r\nPlease, check your account.\r\n\r\nThanks!', 'Label for package was uploaded', 'отправляется дропу</br />админ залил лабел', 'templates'),
(19, 'NEW_LABEL_SMS', 'Dear %DROPNAME%, label for package %PACKAGE_NAME% was uploaded. Check your account.', 'New label (SMS text)', 'отправляется дропу<br />СМС дропу о новой лабел =)', 'templates'),
(20, 'NEW_MESSAGE', 'Hello,\r\nYou have new message in your mailbox.\r\nPlease, check you account.', 'You have new message', 'отправляется дропу<br />админ прислал новое сообщение', 'templates'),
(21, 'WRONG_LABEL', 'Hello,\r\nLabel for package %PACKAGE_ID% was wrong!\r\nAs soon as possible we resend new correct label.\r\n\r\nSorry.', 'Warning! Wrong label for package', 'отправляется дропу<br />админ отменил лабел у пака', 'templates'),
(22, 'NEW_MESSAGE_SMS', 'Hello, you have new message in your mailbox.', 'New Message SMS', 'отправляется дропу<br />СМС дропу о новом сообщении', 'templates'),
(23, 'FORGOT_PASSWORD', 'Your new password: %PASSWORD%', 'Your new password', 'отсылается дропу при восстановлении пароля', 'templates'),
(24, 'NEW_MULTIPLY_PACKAGE', 'Hello,\r\nBeen sent to you a new job.\r\nInvoice number: %PACKAGE_ID%\r\n\r\n%EACH_BEGIN%\r\nTrack: %SHIPPING% # %TRACK%\r\n%EACH_END%', 'You got a new task.', 'отправляется дропу<br />админ подвердил новый мульти-пак от стаффера', 'templates'),
(25, 'NEW_MULTILABELS', 'Hello,\r\nlabel for package %PACKAGE_ID% was uploaded.\r\nInvoice #%PACKAGE_ID%.\r\nPlease, check your account.\r\n\r\nThanks!', 'Label for package was uploaded.', 'отправляется дропу<br />админ залил лабел для мультипака', 'templates'),
(26, 'NEW_MULTILABELS_SMS', 'Dear %DROPNAME%, label for package %PACKAGE_NAME% was uploaded. Check your account.', 'New Multilabels (SMS text)', 'отправляется дропу<br />СМС дропу о новой лабел =)', 'templates');

-- --------------------------------------------------------

--
-- Структура таблицы `Ticket`
--

CREATE TABLE IF NOT EXISTS `Ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `senderId` int(11) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `created` datetime NOT NULL,
  `isClosed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromId` (`created`),
  KEY `toId` (`senderId`),
  KEY `state` (`isClosed`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `Ticket`
--

INSERT INTO `Ticket` (`id`, `senderId`, `subject`, `created`, `isClosed`) VALUES
(5, 4, 'TEST!', '2013-04-08 07:59:25', 0),
(10, 9, 'User ticket 1', '2013-04-10 10:08:45', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(128) NOT NULL,
  `jabber` varchar(64) NOT NULL,
  `state` set('ready','new','problem') NOT NULL DEFAULT 'new',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Дамп данных таблицы `User`
--

INSERT INTO `User` (`id`, `username`, `password`, `email`, `jabber`, `state`, `created`) VALUES
(1, 'boss', 'e6e7c90f52e5ed577d813eb40c5e203b', 'rebelpaha@gmail.com', '0', 'ready', '2013-03-06 00:00:00'),
(4, 'admin', 'e7d3ab76d96642112dbc7ad2c3981674', 'admin@panel.com', '0', 'ready', '2013-04-08 07:57:40'),
(17, 'test2', '2e736c69d4cd6d9814e6a3b45f90ee1e', 'test2@gmail.com', 'test2', 'ready', '0000-00-00 00:00:00'),
(18, 'user3', '0f0f4d49bd9025c8bc0724234248f94b', 'user3@gmail.com', 'user3', 'new', '2013-04-17 10:10:34'),
(19, 'test11', '7258b52a17fe9ed6794802b89385f039', 'test11@egrh.yhy', '', 'new', '2013-06-26 16:38:19'),
(20, 'manager1', '60cab1ec27e2262e82f7b4c0d2af0816', 'manager1@gmail.com', 'manager1@gmail.com', 'ready', '2013-06-26 17:23:57');

-- --------------------------------------------------------

--
-- Структура таблицы `UserManager`
--

CREATE TABLE IF NOT EXISTS `UserManager` (
  `userId` int(11) NOT NULL,
  `managerId` int(11) NOT NULL,
  PRIMARY KEY (`userId`),
  KEY `managerId` (`managerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Связи между дропами и менеджерами';

--
-- Дамп данных таблицы `UserManager`
--

INSERT INTO `UserManager` (`userId`, `managerId`) VALUES
(19, 18);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `AuthAssignment`
--
ALTER TABLE `AuthAssignment`
  ADD CONSTRAINT `authassignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `AuthItemChild`
--
ALTER TABLE `AuthItemChild`
  ADD CONSTRAINT `authitemchild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `authitemchild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
